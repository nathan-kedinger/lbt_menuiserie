<div class ="omaj">
  <h2>Mises à jour du site récentes</h2>
    <?php

      echo '<ul>';

      foreach ($majs as $maj=>$tabInformation){
        //rajouter "../page?"
        echo '<li>','<a href="./'.$majs[$maj]['link'].'">'.$majs[$maj]['tab'].'</a></li>';
      
      }
      echo'</ul>';
    ?></div>