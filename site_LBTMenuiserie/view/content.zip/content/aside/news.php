<div class="news"><h2>Actualités du site</h2>
<p>Le site vient d'être mis en ligne, le 21/07/2022.
    Il reste des erreurs, ainsi que des fautes d'orthographe en route pour être corrigées. 
    Des mises à jour auront lieu jusqu'à ce qu'elles aient toutes été corrigées !
    Les mises à jour prévues et réalisées seront indiquées un peu plus bas.
    Bonne journée à vous et bonne visite !
</p>
</div>