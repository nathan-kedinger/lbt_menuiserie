<?php
    $qualities = [
              ['qualitie' => 'ADAPTATION', 'src' => 'adaptation', 'citation' => 'La chance, c\'est la faculté de s\'adapter instantanément à l\'imprévu;", Alfred CAPUS'],
              ['qualitie' => 'PERSEVERANCE', 'src' => 'perseverance', 'citation' => 'La persévérance est la noblesse de l\'obstination."? Adrien DECOURCELLE'],
              ['qualitie' => 'L\'ECOUTE', 'src' => 'attentif', 'citation' => 'Habitue-toi à être attentif à ce qu\'un autre dit, et autant que possible entre dans l\'âme de celui qui parle.”, Marc-Aurèle'],
              ['qualitie' => 'PATIENCE', 'src' => 'patience', 'citation' => 'Le découragement est beaucoup plus douloureux que la patience.”, HAFIZ'],
            ];


