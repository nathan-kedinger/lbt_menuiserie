<?php
    $majs = [
              ['tab' => 'contact_form', 'link' => 'contact_form.php'],
              ['tab' => 'connexion_form', 'link' => 'connexion_form.php'], 
            ];
