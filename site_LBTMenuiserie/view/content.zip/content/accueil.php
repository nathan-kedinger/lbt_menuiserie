
<img src="../view/ressources/images_homepage/profile_picture.jpg" alt="profile picture">
<h1>NATHAN KEDINGER</h1>
<h3>Étudiant en <strong>informatique</strong> | <strong>Informatic</strong> student</h3>
<h2>Bienvenus sur mon <strong>portfolio</strong></h2>
<p>Vous pourrez trouver ici l'ensembles des compétences et conaissances développées durant mon <strong> BTS SIO OPTION SLAM</strong></p><br>
<a class="boutons" href="contact.php">Contactez-moi</a>     <a class="boutons" href="../view/ressources/images/CV/KEDINGER_CV.pdf" download="KEDINGER_CV.pdf">Téléchargez mon cv</a>