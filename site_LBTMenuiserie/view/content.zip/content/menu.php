<?php
    $menu = [
              ['tab' => HOMEPAGE, 'link' => 'homepage.php'],
              ['tab' => CV,'link' => 'cv.php'], 
              ['tab' => REALISATIONS,'link' => 'ppe.php'], 
              ['tab' => SKILLS, 'link' => 'skills.php'],
              ['tab' => WATCH, 'link' => 'watch.php',
                  ['utab' => 'watch_law', 'ulink' => 'watch_law.php'],
                  ['utab' => 'watch_ia', 'ulink' => 'watch_ia.php'],
              ], 
              ['tab' => BTS, 'link' => 'bts.php'], 
              ['tab' => CONTACT, 'link' => 'contact.php'], 
            ];


