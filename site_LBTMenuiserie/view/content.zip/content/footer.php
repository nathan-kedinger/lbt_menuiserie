<footer>
        <a href="#title"><img class="logo-fleche" src="../view/ressources/logo/logo-fleche.png"></a>
        <p>© KEDINGER Nathan | Tous droits Réservés</p>
        <a href="">Mentions légales</a>
</footer>