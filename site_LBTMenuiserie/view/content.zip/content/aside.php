<?php
  include 'tab/maj.php';

  require_once '../view/content/aside/news.php';
  require_once '../view/content/aside/future-maj.php';
  require_once '../view/content/aside/old-maj.php';