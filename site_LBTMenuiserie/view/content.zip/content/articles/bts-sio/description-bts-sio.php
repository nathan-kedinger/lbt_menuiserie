<article>
    <h2>DÉSCRIPTION BTS SIO</h2>
    <p>Le BTS SIO :"Service Informatique aux Organisations" est un diplôme qui comprend deux options : SLAM et SISR.
        L'option SISR, Solutions d'Infrastrucure, Systèmes et Réseaux, s'occupe de former des étudiants à assurer
        la disponibilité des services informatiques existants. Le futurs travailleurs apprendront également à prendre 
        en compte les besoins de l'entreprise et accompagner sa transformation numérique. Ils acquierent les compétences pour gérer le patrimoine informatique,
        répondre aux incidents.
        L'option SLAM, Solutions Logicielles et Applications Métiers, est l'option que j'ai choisie.
        Pour sa part, elle s'interesse à la partie développement et maintenance des composants logiciels d'une solution applicative. 
    </p>

    <h2>LE PROGRAMME DE MA FORMATION</h2>
        <p>Le programme de la formation à distance que j'ai pu suivre via l'école en ligne <a href="https://www.studi.com/fr">STUDI</a> est découpé
        en plusieurs grandes parties : 
    -Support et mise à disposition des services informatiques : Il est question de veilles, de gestion de parc informatique , du déroulement d'un travail
      de ticketing, mais également un cours complet sur le cms Wordpress.
    -L'enseignement de la spécialité SLAM : C'est la grosse partie de l'enseignement. La première parti de ce cours est orienté web
    On commence avec les basique HTML CSS, on pousse un peu sur les bases de JavaScript et on attaque un peu plus fort avec l'architecture de projet et PHP et la programmation orientée objet.
    Vient ensuite un cours sur les bases de données . Il est évidemment question de sécurité, de maintenabilité, de travail en équipe, de bonne pratiques... On approfondi les différents langages
avec quelques bibliothèque (bootstrap, symphony...) et on finit ce cours par un cours sur le langage JAVA.
C'est le plus gros cours de l'enseignement, et il est assez dense, mais les sujet y sont variés, amener dans un ordre qui suit une logique assez cohérente, de différents paradigme.
La précision des connaissances évoluent avec la complexité des cours.
-Le cours de cybersécurité :Il est question de la sécurisation des données en général, et des bonnes pratique à mettre en place pour minimiser les risques et rester dans la légalité envers 
les clients. Un cours optionnel SISR est disponnible également pour comprendre le fonctionnement de la machine
- Le cours de culture générale et expression reprend le cours du tronc commun à l'ensemble des BTS.
- Le cours d'anglais qui donne des clées de langage technique. la plateforme donne égalment accès à différentes applications d'apprentissage de la langue ainsi que des cours de préparation au toeic.
-Les mathématiques
-Culture économique et managériale : Ce cours donne un aperçu très large de ce qu'est le droit français1. Il est question des droits du contrat, des droits européens, des statuts d'entreprise, de management... Ce cours est 
également très dense.
-Bonus Par ailleurs, la plateforme donne également accès à des outils comme  github student developer pack, office 365... mais également d'autres cours très intéressants comme des cours sur aws, sur des maths pour la comptabilité
des cours de référencement, de bureautique, adobe, microsoft, google, de logiciel de paie, Sage... </p>

</article>