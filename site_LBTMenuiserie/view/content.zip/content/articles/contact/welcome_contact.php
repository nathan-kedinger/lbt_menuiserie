<article>
    <h2>Laissez-moi un message après le clic</h2>
    <p>Bonjour et bienvenus dans la zone contact. C'est ici que vous pouvez échanger avec moi, 
    me poser une question ou me laisser tout type de commentaires, afin que je vous recontact.</p>
</article>