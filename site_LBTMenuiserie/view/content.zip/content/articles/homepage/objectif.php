<article>
    <h2>OBJECTIFS DU SITE</h2>
    <p>L'objectif de ce site internet est pluriel :</p>
    <br>
        <p>Le premier objectif est de montrer les compétences acquises pour d'éventuels employeurs, partenaires et pourquoi pas clients.</p>
        <p>Le deuxième objectif est d'utiliser ce média comme laboratoire d'expérience, et pourquoi pas d'échange.</p>
       <p> Le troisième objectif est de créer une base solide pour répondre à des demandes clients.
        L'intérêt d'avoir une architecture (SOLID)e est que le code devient beaucoup plus portable.</p>
        <p>C'est par mon souhait de répondre à ces objectifs, que j'apprends tous les jours et que 
        j'expérimente.
    </p>
</article>