<article>
            <h2>Qui suis-je?</h2>
            <p>Bonjour, je m'appelle Nathan KEDINGER, j'ai aujourd'hui 29 ans, et après un beau panel 
                d'expériences de vie et professionnelles, je me reconverti à l'informatique.
                Je vous laisse retrouver une description plus détaillée de mes expériences <a href="skills.php">ici</a> 
                si cela vous intéresse.
                Je suis passionné par la technologie et tout l'aspect constructif, logique et évolutif
                qui entoure la programmation.
                Je souhaite me former dans ce domaine pour y travailler sur le long terme.
                J'envisage de poursuivre les études en ce sens jusqu'au master.
            </p>
</article>