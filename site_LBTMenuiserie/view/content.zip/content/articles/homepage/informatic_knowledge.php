<article>
    <h2>CONNAISSANCCES INFORMATIQUE</h2>

    <img src="../view/ressources/logo/logo-web.png" alt="Web"><p class="vert-rouge">
    &ensp;HTML&ensp;CSS&ensp;&ensp;&emsp;PHP&ensp;&ensp;&emsp;JS&ensp;&ensp;WordPress
    </p>
    <br>
    <img src="../view/ressources/logo/logo-programmation.png" alt="Programmation">
    <p class="vert-rouge">
    &emsp;C&emsp;&emsp;&emsp;&emsp;&emsp;C++&emsp;&emsp;&emsp;&emsp;&emsp;C#&emsp;JAVA
    </p>
    <br>
    <img src="../view/ressources/logo/logo-bdd.png" alt="SQL">
    <p class="vert-rouge">
    &emsp;&emsp;&emsp;&emsp;&emsp;SQL => MySQL&emsp;&emsp;
    </p>
    <br>
    <img src="../view/ressources/logo/logo-informatique.png" alt="Informatique">
    <p class="vert-rouge">
        Windows&ensp; Word &ensp; Linux&ensp;    Excel       
    </p>
    <br>
    <img src="../view/ressources/logo/logo-team.png" alt="Équipe">
    <p class="vert-rouge">
         VSCode&ensp;  Xampp&ensp;  Github&ensp;   &ensp;Git  &ensp;  PowerPoint  
    </p>
</article>

