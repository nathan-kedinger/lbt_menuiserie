<?php 
    require '../view/content/tab/qualities.php';
?>
  <article>
    <h2>MES QUALITÉS</h2>
    <div class ="qualities">
    <?php

        //$tabInformation = tab key
      foreach ($qualities as $qualitie=>$tabInformation)
      {
        echo  '<div class="'.$qualities[$qualitie]['qualitie'].'">
                <div class="qualitie">
                  <img alt="'.$qualities[$qualitie]['qualitie'].'" src="../view/ressources/images/qualities/'.$qualities[$qualitie]['src'].'.jpg">
                  <h4>'.$qualities[$qualitie]['qualitie'].'</h4>
                  <p>"'.$qualities[$qualitie]['citation'].'</p>
                </div>
              </div>';
      }

    ?></div>
  </article>