<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title><?php echo $pageTitle?></title>
  <link rel="stylesheet" type="text/css" href="../view/css/style.scss"> 
  <link rel="icon" type="image/svg" size="16x16" href="../view/ressources/logo/logo_NK.svg">
</head>